export const OCTOKIT = 'OCTOKIT';
export const OCTOKIT_OPTIONS = 'OCTOKIT_OPTIONS';
