export const S3_MODULE_CONNECTION = 'default';
export const S3_MODULE_CONNECTION_TOKEN = 'S3ModuleConnectionToken';
export const S3_MODULE_OPTIONS_TOKEN = 'S3ModuleOptionsToken';
